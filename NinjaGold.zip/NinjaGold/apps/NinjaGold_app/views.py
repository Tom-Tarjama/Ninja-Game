# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect

import random

from time import time, strftime, localtime

# Create your views here.

def index(request):

	if 'total_gold' not in request.session:
		request.session['total_gold'] = 0

	if 'activities' not in request.session:
		request.session['activities'] = []

	return render(request, "NinjaGold_app/index.html")

def process(request):

	context = {}

	if request.POST['building'] == "farm":
		context['winnings'] = random.randrange(10,21)
		context['time'] = strftime("%Y/%m/%d %I:%M %p", localtime())
		context['message'] = "You earned {} gold from the farm! ({})". format(context['winnings'], context['time'])

	elif request.POST['building'] == "cave":
		context['winnings'] = random.randrange(5,11)
		context['time'] = strftime("%Y/%m/%d %I:%M %p", localtime())
		context['message'] = "You earned {} gold from the cave! ({})". format(context['winnings'], context['time'])

	elif request.POST['building'] == "house":
		context['winnings'] = random.randrange(2,6)
		context['time'] = strftime("%Y/%m/%d %I:%M %p", localtime())
		context['message'] = "You earned {} gold from the house! ({})". format(context['winnings'], context['time'])

	elif request.POST['building'] == "casino":
		context['winnings'] = random.randrange(-50,51)
		context['time'] = strftime("%Y/%m/%d %I:%M %p", localtime())
		if context['winnings'] < 0:
			context['message'] = "Oh noes! You lost {} gold at the casino! ({})". format(abs(context['winnings']), context['time'])
		elif context['winnings'] == 0:
			context['message'] = "Meh. You broke even at the casino."
		elif context['winnings'] > 0:
			context['message'] = "Congrats! You won {} gold at the casino! ({})". format(context['winnings'], context['time'])

	# print context

	request.session['total_gold']+=context['winnings']

	# print request.session['total_gold']

	request.session.modified = True
	request.session['activities'].append(context)

	print "LOOK HERE", request.session['activities']

	return redirect("/")

def reset(request):
	request.session.clear()

	return redirect("/")



